package ab1;

public class thread { public void run() {
    System.out.println("Thread is running...");
    try {
        Thread.sleep(1000); // Timed Waiting
    } catch (InterruptedException e) {
        System.out.println("Thread interrupted.");
    }
    System.out.println("Thread finished.");
}

public static void main(String[] args) {
    MyThread t1 = new MyThread();
    System.out.println("Thread state after creation: " + t1.getState()); // NEW
    t1.start();
    System.out.println("Thread state after start(): " + t1.getState()); // RUNNABLE

    try {
        t1.join(); // Main thread waits
    } catch (InterruptedException e) {
        e.printStackTrace();
    }

    System.out.println("Thread state after completion: " + t1.getState()); // TERMINATED
}

}
